import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class preguntafos {
    public static void main(String[] args) {
        List<String> preguntas = leerPreguntas("preguntas.txt");
        List<String> respuestas = leerRespuestas("respuestas.txt");
        int totalPreguntas, aciertos;
        int[] index_preguntas;

        mensajeBienvenida();
        totalPreguntas = obtenerNumeroPreguntas(preguntas);
        index_preguntas = obtenerIndicesDeLasPreguntas(totalPreguntas, preguntas.size());
        aciertos = jugarQuiz(index_preguntas, preguntas, respuestas);

        guardarPuntuacion(aciertos, totalPreguntas);
    }

    private static List<String> leerPreguntas(String archivo) {
        List<String> preguntas = new ArrayList<>();
        try {
            File file = new File(archivo);
            Scanner scanner = new Scanner(file);
            while (scanner.hasNextLine()) {
                String pregunta = scanner.nextLine();
                preguntas.add(pregunta);
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("Error al leer el archivo de preguntas: " + e.getMessage());
        }
        return preguntas;
    }

    private static List<String> leerRespuestas(String archivo) {
        List<String> respuestas = new ArrayList<>();
        try {
            File file = new File(archivo);
            Scanner scanner = new Scanner(file);
            while (scanner.hasNextLine()) {
                String respuesta = scanner.nextLine();
                respuestas.add(respuesta);
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("Error al leer el archivo de respuestas: " + e.getMessage());
        }
        return respuestas;
    }

    private static void mensajeBienvenida() {
        System.out.println("Bienvenidos al Quiz");
    }

    private static int obtenerNumeroPreguntas(List<String> preguntas) {
        Scanner scanner = new Scanner(System.in);
        int numeroPreguntas;
        do {
            System.out.print("¿Cuántas preguntas deseas responder? (5 - " + preguntas.size() + "): ");
            while (!scanner.hasNextInt()) {
                System.out.println("Por favor ingresa un número válido.");
                scanner.next();
            }
            numeroPreguntas = scanner.nextInt();
            scanner.nextLine();
        } while (numeroPreguntas < 5 || numeroPreguntas > preguntas.size());
        return numeroPreguntas;
    }

    private static int[] obtenerIndicesDeLasPreguntas(int totalPreguntas, int cantidadPreguntas) {
        int[] indexes = new int[totalPreguntas];
        int random_index, j;
        boolean indice_repetido;

        for (int i = 0; i < indexes.length; i++) {
            indexes[i] = -1;
        }

        for (int i = 0; i < indexes.length; i++) {
            do {
                indice_repetido = false;
                j = 0;
                random_index = (int) Math.round(Math.random() * (cantidadPreguntas - 1));
                while (!indice_repetido && j < indexes.length) {
                    if (random_index == indexes[j]) {
                        indice_repetido = true;
                    } else {
                        j++;
                    }
                }
                if (indice_repetido) {
                    continue;
                }
            } while (indice_repetido);
            indexes[i] = random_index;
        }
        return indexes;
    }

    private static int jugarQuiz(int[] index_preguntas, List<String> preguntas, List<String> respuestas) {
        int aciertos = 0;

        for (int i = 0; i < index_preguntas.length; i++) {
            System.out.println("Pregunta " + (i + 1) + ": " + preguntas.get(index_preguntas[i]));
            String respuestaUsuario = obtenerRespuesta();

            if (verificarRespuesta(respuestaUsuario, respuestas.get(index_preguntas[i]))) {
                System.out.println("¡Respuesta correcta!");
                aciertos++;
            } else {
                System.out.println("Respuesta incorrecta. La respuesta correcta es: " + respuestas.get(index_preguntas[i]));
            }
        }

        return aciertos;
    }

    private static String obtenerRespuesta() {
        Scanner scanner = new Scanner(System.in);
        String respuesta;
        do {
            System.out.print("Respuesta (S/N): ");
            respuesta = scanner.nextLine().toLowerCase();
        } while (!respuesta.equals("s") && !respuesta.equals("n"));
        return respuesta;
    }

    private static boolean verificarRespuesta(String respuestaUsuario, String respuestaCorrecta) {
        return respuestaUsuario.equalsIgnoreCase(respuestaCorrecta);
    }

    private static void mensajeFinal(int aciertos, int totalPreguntas) {
        double porcentajeAciertos = (double) aciertos / totalPreguntas * 100;

        System.out.println("¡Has completado el juego!");
        System.out.println("Aciertos: " + aciertos + "/" + totalPreguntas);
        if (porcentajeAciertos <= 33) {
            System.out.println("¡Eres un zoquete! Respondiste correctamente menos del 33% de las preguntas.");
        } else if (porcentajeAciertos <= 66) {
            System.out.println("¡Aún te queda camino! Respondiste correctamente del 34% al 66% de las preguntas.");
        } else if (porcentajeAciertos <= 99) {
            System.out.println("¡Vas muy bien! Respondiste correctamente del 67% al 99% de las preguntas.");
        } else {
            System.out.println("¡Eres el mejor! Respondiste correctamente el 100% de las preguntas.");
        }}
        private static void guardarPuntuacion(int aciertos, int totalPreguntas) {
            Scanner scanner = new Scanner(System.in);
            System.out.print("¿Deseas guardar tu puntuación? (S/N): ");
            String respuesta = scanner.nextLine().toLowerCase();
            if (respuesta.equals("s")) {
                System.out.print("Ingresa tu nombre: ");
                String nombre = scanner.nextLine();
                try {
                    FileWriter fileWriter = new FileWriter("puntuaciones.txt", true);
                    fileWriter.write(nombre + ": " + aciertos + "/" + totalPreguntas + "\n");
                    fileWriter.close();
                    System.out.println("Puntuación guardada exitosamente.");
                } catch (IOException e) {
                    System.out.println("Error al guardar la puntuación: " + e.getMessage());
                }
            }
        }
    }
